let uploadElementsList = document.getElementById("uploadElementsList");
let saveMediaFile = document.getElementById("saveMediaFile");
let getNextElement = document.getElementById("getNextElement");
let trickLabel = document.getElementById("trickLabel");
let trickImage = document.getElementById("trickImage");
let trickMemorized = document.getElementById("trickMemorized");
let downloadElementsList = document.getElementById("saveElementsList");
let startTest = document.getElementById("startTest");
let questionCount = document.getElementById("questionCount");
let answerCount = document.getElementById("answerCount");
let level1 = document.getElementById("level1");
let level2 = document.getElementById("level2");
let level3 = document.getElementById("level3");
let labelLevel1 = document.getElementById("labelLevel1");
let labelLevel2 = document.getElementById("labelLevel2");
let labelLevel3 = document.getElementById("labelLevel3");
let nextQuestion = document.getElementById("nextQuestion");
let endTest = document.getElementById("endTest");
let questionsList = document.getElementById("questionsList");

let level11 = document.getElementById("level11");
let level12 = document.getElementById("level12");
let level13 = document.getElementById("level13");
let labelLevel11 = document.getElementById("labelLevel11");
let labelLevel12 = document.getElementById("labelLevel12");
let labelLevel13 = document.getElementById("labelLevel13");

let tricks = [];
let currentElement = 0;

let tests = [];
let currentTest = -1;
let currentQuestion = 0;

class Trick {
    name = "";
    media = "";
    level = "";
    memorized = false;

    constructor(name, level, memorized, media) {
        this.name = name;
        this.media = media;
        this.level = level;
        this.memorized = memorized;
    }
}

class Test {
    countQuestions = 0;
    countVariantsOfAnswers = 0;
    testLevel = "";
    questions = [];
    answersVariants = [];
    answers = [];
    countRightAnswers = 0;

    constructor(countQuestions, countVariantsOfAnswers, testLevel, questions, answersVariants) {
        this.countQuestions = countQuestions;
        this.countVariantsOfAnswers = countVariantsOfAnswers;
        this.testLevel = testLevel;
        this.questions = questions;
        this.answersVariants = answersVariants;
    }
}

downloadElementsList.addEventListener("click", async () => {
    let text = "";
    for(let i = 0; i < tricks.length; ++i) {
        let bool = tricks[i].memorized === "false" ? "" : "1";
        text += tricks[i].name + "." + tricks[i].level + "." + bool + "." + tricks[i].media + "\r\n";
    }

    let element = document.createElement('a');
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
    element.setAttribute('download', 'list.txt');
    element.style.display = 'none';

    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
});

uploadElementsList.addEventListener("click", async () => {
    let file = document.getElementById("tricks");
    let text = await (new Response(file.files[0])).text();
    let data = text.split("\r\n");

    if (text === "") {
        return;
    }

    alert("Файл загружен");

    for(let i = 0; i < data.length - 1; ++i) {
        let row = data[i].split(".");
        tricks.push(new Trick(row[0], row[1], row[2], row[3]));
    }

    localStorage.setItem("tricks", JSON.stringify(tricks))
});

let currentMedia = "";
let mediaFile = document.querySelector("#mediaFile");
mediaFile.addEventListener("change", function() {
    const reader = new FileReader();

    reader.addEventListener("load", () => {
        currentMedia = reader.result;
    })

    reader.readAsDataURL(this.files[0]);
});

saveMediaFile.addEventListener("click", async () => {
    let trickName = document.getElementById("newElementName").value;

    let trickLevel = "";
    if (level11.checked === true) {
        trickLevel = labelLevel11.innerText;
    } else if (level12.checked === true) {
        trickLevel = labelLevel12.innerText;
    } else if (level13.checked === true) {
        trickLevel = labelLevel13.innerText;
    }

    if (trickName === "" || trickLevel === "" || currentMedia === undefined) {
        return;
    }

    tricks.push(new Trick(trickName, trickLevel, false, currentMedia));

    localStorage.setItem("tricks", JSON.stringify(tricks))

    alert("Элемент сохранен в список.")
});

trickMemorized.addEventListener("click", async () => {
    tricks[currentElement].memorized = trickMemorized.checked === true;
});

getNextElement.addEventListener("click", async () => {
    if (tricks.length === 0) {
        tricks = JSON.parse(localStorage.getItem("tricks"))
    }

    ++currentElement;
    if (currentElement >= tricks.length) {
        currentElement = 0;
    }

    trickImage.src = tricks[currentElement].media;
    trickImage.onload = () => {
        URL.revokeObjectURL(trickImage.src);
    }
    trickLabel.innerText = "Название: " + tricks[currentElement].name;
    document.getElementById("trickLevel").innerText = "Уровень: " + tricks[currentElement].level;
    trickMemorized.checked = tricks[currentElement].memorized;
});

function shuffle(array) {
    array.sort(() => Math.random() - 0.5);
    return array;
}

function randomInteger(min, max) {
    let rand = min + Math.random() * (max + 1 - min);
    return Math.floor(rand);
}

startTest.addEventListener("click", async () => {
    questionsList.innerHTML = '';
    ++currentTest;
    let questions = [];
    let answersVariants = [];
    let countQuestions = questionCount.value > 0 && questionCount.value < 100 ? questionCount.value : 3;
    let countVariantsOfAnswers = answerCount.value > 1 && answerCount.value < 10 ? answerCount.value : 3;

    let testLevel;
    if (level1.checked === true) {
        testLevel = labelLevel1.innerText;
    } else if (level2.checked === true) {
        testLevel = labelLevel2.innerText;
    } else if (level3.checked === true) {
        testLevel = labelLevel3.innerText;
    }

    let testLevelTricks = tricks.filter(item => item.level === testLevel);
    let shuffledTricks = shuffle(testLevelTricks.slice(0));

    for (let i = 0; i < countQuestions; ++i) {
        if (i >= shuffledTricks.length) {
            break;
        }

        questions.push(shuffledTricks[i]);
    }

    for (let i = 0; i < countQuestions; ++i) {
        if (i >= shuffledTricks.length) {
            break;
        }

        let answersI = [];
        answersI.push(questions[i]);

        let indexes = []
        indexes.push(i);

        for (let j = 1; j < countVariantsOfAnswers; ++j) {
            if (j >= shuffledTricks.length) {
                break;
            }

            let randomIndex = randomInteger(0, countQuestions - 1);
            while (indexes.includes(randomIndex)) {
                randomIndex = randomInteger(0, countQuestions - 1);
            }

            answersI.push(questions[randomIndex]);
            indexes.push(randomIndex);
        }

        answersVariants.push(answersI);
    }

    tests.push(new Test(countQuestions, countVariantsOfAnswers, testLevel, questions, answersVariants));

    let html = "<p>Выберите верное название трюка:</p><img id=\"question0\" alt=\"\" width=\"400\" height=\"auto\" src=" + questions[0].media + "><br><p id=\"levelList\">";
    for (let i = 0; i < countVariantsOfAnswers; ++i) {
        if (i >= shuffledTricks.length) {
            break;
        }

        html += "<input type=\"radio\" name=\"answer\" id=\"answer"+ i +"\">" +
            "<label for=\"answer" + i + "\">" + answersVariants[0][i].name + "</label><br>";
    }

    questionsList.insertAdjacentHTML('afterbegin', html + '</p>');
});

let saveTestResult = document.getElementById("saveTestResult");
let testFileName = document.getElementById("testFileName");
saveTestResult.addEventListener("click", () => {
    if (testFileName.value === "") {
        return;
    }

    let data = "";
    data += "test name;count questions;count right answers\r\n"
    for(let i = 0; i < tests.length; ++i) {
        for (let j = 0; j < tests[i].questions.length; ++j) {
            if (tests[i].answers[j] === tests[i].questions[j].name) {
                ++tests[i].countRightAnswers;
            }
        }

        data += "Test" + i + ";" + tests[i].countQuestions + ";" + tests[i].countRightAnswers + "\r\n";
    }

    let element = document.createElement('a');
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(data));
    element.setAttribute('download', testFileName.value + '.csv');
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
});

nextQuestion.addEventListener("click", () => {
    if (currentQuestion === tests[currentTest].questions.length - 1) {
        endTest.click();
        return;
    }
    ++currentQuestion;

    questionsList.innerHTML = '';

    let html = "<p>Выберите верное название трюка:</p><img id=\"question0\" alt=\"\" width=\"400\" height=\"auto\" src=" +
        tests[currentTest].questions[currentQuestion].media + "><br><p id=\"levelList\">";
    for (let i = 0; i < tests[currentTest].countVariantsOfAnswers; ++i) {
        if (i >= tests[currentTest].questions.length) {
            break;
        }

        html += "<input type=\"radio\" name=\"answer\" id=\"answer"+ i +"\">" +
            "<label for=\"answer" + i + "\" id=\"labelAnswer" +i + "\">" + tests[currentTest].answersVariants[currentQuestion][i].name + "</label><br>";
    }

    questionsList.insertAdjacentHTML('afterbegin', html + '</p>');

    for (let i = 0; i < tests[currentTest].countVariantsOfAnswers; ++i) {
        let radioButton = document.getElementById("answer" + i);
        let label = document.getElementById("labelAnswer" + i);

        radioButton.addEventListener("click", () => {
            tests[currentTest].answers[i] = label.innerText;
        });
    }
});

endTest.addEventListener("click", () => {
    questionsList.innerHTML = '';
    currentQuestion = 0;
});